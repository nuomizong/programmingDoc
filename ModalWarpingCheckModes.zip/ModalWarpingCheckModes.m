function ModalWarpingCheckModes2web(modelname)

    bLoadPreCompute = false;

    if ~ischar(modelname)
	  error('Input arg must be a string (enclosed in single quotes).');
    end
    
    if length(modelname)<4 || ~strcmpi(modelname( (end-3):end),'.vol')
	  modelVOLname=[modelname,'.vol'];
    else
	  modelVOLname = modelname;
	  modelname = modelname(1:end-4);
    end
    
    if ~exist(modelVOLname,'file')
	  error('Non-existent VOL model.')
    end
  
    bLoadPreCompute = false;
    modelMATname=[modelname,'.mat'];

    if exist( modelMATname,'file')
	  bLoadPreCompute = true;
    end
    
%% Init GUI

fig = gcf;
clf;
set(fig,'WindowStyle','docked');
axsz=30;
axis([-axsz axsz -axsz axsz -axsz axsz]);

cameratoolbar;

modetxt=uicontrol('Style','edit', 'Position',[20 110 80 20],   'String','1',...
    'callback','ModeEditCallback(gcbo,gcbf)');
eigenvtxt=uicontrol('Style','text', 'Position',[20 140 80 20],   'String','0');
uicontrol('pos',[20 200 80 20],'string','pause','fontsize',10, ...
    'callback','pause(gcbo,gcbf)' );
uicontrol('pos',[20 170 80 20],'string','warp','fontsize',10, ...
    'callback','ModeWarpCallback(gcbo,gcbf)' );
uicontrol('pos',[20 80 80 20],'string','mode up','fontsize',10, ...
    'callback','ModeUpCallback(gcbf)' );
uicontrol('pos',[20 50 80 20],'string','mode down','fontsize',10, ...
    'callback','ModeDownCallback(gcbf)'     );
uicontrol('pos',[20 20 80 20],'string','quit','fontsize',10, ...
    'callback','close(gcf); clear functions;');
uicontrol('pos',[110 40 80 20],'string','dt up','fontsize',10, ...
    'callback','dtUpCallback(gcf)');
uicontrol('pos',[110 20 80 20],'string','dt down','fontsize',10, ...
    'callback','dtDownCallback(gcf)');
uicontrol('pos',[190 40 80 20],'string','amp up','fontsize',10, ...
    'callback','ampUpCallback(gcf)');
uicontrol('pos',[190 20 80 20],'string','amp down','fontsize',10, ...
    'callback','ampDownCallback(gcf)');

%% Init mesh

    [X,Tes,Srf]=VolLoader(modelVOLname);
    % init the world coords of undeformed mesh points
    x0=X'; x0=x0(:);
    N=size(X,1);

    s = trisurf(Srf,X(:,1),X(:,2),X(:,3));

    camlookat(s);
    alpha(0.6);
    colormap(autumn);
    camproj('perspective');
    axis square equal auto off;

%% Build physics props (K, M, Eigendecomposition)
    dt=0.03;
    ModeNum= 3*N;
    % physical parameters
    rho=1;    % mass density
    lambda=100; % ~ compression resistance
    mu=100;  % ~ shear resistance
    c1=0; % K coefficient in C (damping matrix) - UNUSED IN THIS VER
    c2=0; % M coefficient in C (damping matrix) - UNUSED IN THIS VER
    %h= 0.01 *prod(sz);   % the simulation's dt

    if bLoadPreCompute
	  load(modelMATname);  % contains Phi , d , W
    else
	  K=-FEMBuildK(X,Tes,lambda,mu);
	  M=FEMBuildM(X,Tes,rho);
	  [Phi,d]=ComputePhiD(K,M);
	  W=-buildW(X,Tes);
	  
	  save(modelMATname,'Phi','d','W');
    end

%% init userdata
    data.Mode=1;
    data.EigenValues=d;
    data.NumModes=ModeNum;
    data.ModeTxtHandle = modetxt;
    data.EigenVTxtHandle = eigenvtxt;
    data.dt =  dt;
    data.amp = 50;
    data.warp=false;
    data.pause=false;
    
    set(fig,'userdata',data);  % init displayed mode

%% Main Loop!
    ii=0;    % i taken in nested func

    while ishandle(s)
	  dat=get(fig,'userdata');


	  if ~dat.pause
		ii=mod(ii+dat.dt,2*pi);
	  end

	  u = Phi(:,dat.Mode) .* (dat.amp*sin(ii) ) ;

	  if dat.warp
		w=W *u;
		R=ComputeModalRotationMat(-w);
		u = R * u ;
	  end  %if

	  %   Render Update
	  set(s,'vertices',reshape(x0 +u,3,N).');
	  drawnow
    end %while

%% ----------- Nested Functions

    % ComputeModalRotationMat - nested
    function R=ComputeModalRotationMat(w)
	  % computes R~ from the concatenated vector of rotators, w
	  % w must be a column vector (not checked).

	  persistent ww wMat Iidx Jidx snMat csMat  csMatI csMatJ

	  if isempty(wMat) % first call - init indexation vecs
		IncIdx = (0:(N-1)).' .* 3;
		IncIdx = IncIdx(:, [ 1 1 1 1 1 1]) ;

		Iidx = [3 1 2 2 3 1];
		Iidx = Iidx(ones(N,1),:);
		Iidx = Iidx + IncIdx;
		Iidx = Iidx.';
		Iidx = Iidx(:);

		Jidx = [2 3 1 3 1 2];
		Jidx = Jidx(ones(N,1),:);
		Jidx = Jidx + IncIdx;
		Jidx = Jidx.';
		Jidx = Jidx(:);

		csMatI =  [1:ModeNum 1:ModeNum 1:ModeNum].' ;

		csMatJ = [ 1:3:ModeNum 2:3:ModeNum 3:3:ModeNum];
		csMatJ = csMatJ([1 1 1],:);
		csMatJ = csMatJ(:);
	  end

	  ww=reshape(w,3,N);
	  wnorm=sqrt(sum(ww.^2));
	  wnorm=wnorm+(abs(wnorm)<0.0001);   % put 1 if equals 0
	  wnormalized= ww./ wnorm([1;1;1],:);  % that's why

	  cs = (1 - cos(wnorm)) ./ wnorm;
	  sn=  1 -  sin(wnorm)./wnorm;

	  cs=cs([1 1 1],:);
	  cs=cs(:);
	  %     csMat=cs(:,OnesModeNum);
	  csMat = sparse( csMatI, csMatJ , [ cs ; cs ;cs]);

	  sn=sn([1 1 1],:);
	  sn=sn(:);
	  snMat=sparse( csMatI, csMatJ , [ sn ; sn ; sn]);

	  wMat = sparse( Iidx , Jidx, [wnormalized ; -wnormalized]);


	  R=speye(ModeNum) +  wMat .* csMat +  wMat*wMat .*  snMat  ;

    end  % ComputeModalRotationMat-  nested !


end % main
%% ------------ SubFunctions

% build Phi, d - precompute

function [Phi,d]=ComputePhiD(K,M)
    tic
    [PhiUnsorted,DUnsorted]=eig(K,M);    % d is a diagonal MATRIX
    [d,permidx]=sort(diag(DUnsorted));
    Phi = PhiUnsorted(:,permidx);
    clear DUnsorted PhiUnsorted;
    t=toc; 	disp(sprintf('generalized eigen decomp time: %6.2g ',t))

end %ComputePhiD

% build W - precompute
function W=buildW(X,Tes)

    tic

    N=size(X,1);
    NT=size(Tes,1);
    W=zeros(3*N);
    Counter=zeros(1,N);

    % summing
    for i=1:NT;
	  ind=Tes(i,:);
	  V=X(ind,:);   % a 4x3 matrix, the rows are the vertices' coordinates.
	  vol12 = 2 * abs(det(diff(V)));

	  T=[CrossMat(cross(V(2,:),V(3,:))+cross(V(3,:),V(4,:))+cross(V(4,:),V(2,:)) ),...
		CrossMat(cross(V(3,:),V(1,:))+cross(V(4,:),V(3,:))+cross(V(1,:),V(4,:))),...
		CrossMat(cross(V(1,:),V(2,:))+cross(V(2,:),V(4,:))+cross(V(4,:),V(1,:))),...
		CrossMat(cross(V(2,:),V(1,:))+cross(V(1,:),V(3,:))+cross(V(3,:),V(2,:)))];
	  T=T/vol12;

	  Counter(ind) = Counter(ind) +1;

	  indW=[3;3;3]*ind + [-2 -2 -2 -2;-1 -1 -1 -1;0 0 0 0];
	  indW=indW(:);

	  W(indW,indW) =W(indW,indW) + kron([1;1;1;1],T);

    end  %i

    % averaging
    if any(Counter==0)
	  error('A vertex unassigned to any tetra!');
    end
    Counter=Counter([1;1;1],:);
    Counter=Counter(:);
    Counter=Counter(:,ones(1,3*N));
    W=W./Counter;

    W=sparse(W);

    t=toc;    
    disp(sprintf('buildW time: %6.2g ',t));

end   % buildW
%%
function ModeUpCallback(fig)
    data=get(fig,'userdata');
    data.Mode=mod(data.Mode,data.NumModes) + 1;
    set(fig,'userdata',data);
    set(data.ModeTxtHandle,'String',sprintf('%g',data.Mode) );
    set(data.EigenVTxtHandle,'String',sprintf('%g',data.EigenValues(data.Mode)));
end %ModeUpCallback
%%
function ModeDownCallback(fig)
    data=get(fig,'userdata');
    data.Mode=data.NumModes-mod(1-data.Mode,data.NumModes);
    set(fig,'userdata',data);
    set(data.ModeTxtHandle,'String',sprintf('%g',data.Mode) );
    set(data.EigenVTxtHandle,'String',sprintf('%g',data.EigenValues(data.Mode)));
end %ModeDownCallback
%%
function ModeWarpCallback(obj,fig)
    data=get(fig,'userdata');
    data.warp=~data.warp;
    set(fig,'userdata',data);
    if data.warp
	  set(obj,'string','unwarp');
    else
	  set(obj,'string','warp');
    end %if
end  % ModeWarpCallback
%%
function pause(obj,fig)
    data=get(fig,'userdata');
    data.pause=~data.pause;
    set(fig,'userdata',data);
end %pause
%%
function dtUpCallback(fig)
    data=get(fig,'userdata');
    data.dt=1.1*data.dt;
    set(fig,'userdata',data);
end %dtUpCallback
%%
function dtDownCallback(fig)
    data=get(fig,'userdata');
    data.dt=0.9*data.dt;
    set(fig,'userdata',data);
end %dtDownCallback
%%
function ampUpCallback(fig)
    data=get(fig,'userdata');
    data.amp=1.1*data.amp;
    set(fig,'userdata',data);
end    % ampUpCallback
%%
function ampDownCallback(fig)
    data=get(fig,'userdata');
    data.amp=0.9*data.amp;
    set(fig,'userdata',data);
end    % ampDownCallback
%%
function	  ModeEditCallback(obj,fig)
    data=get(fig,'userdata');
    val=floor(str2double(get(obj,'string')));    % too lazy for type check
    data.Mode = max(1,min(val,data.NumModes)) ;

    set(fig,'userdata',data);
    set(data.ModeTxtHandle,'String',sprintf('%g',data.Mode) );
    set(data.EigenVTxtHandle,'String',sprintf('%g',data.EigenValues(data.Mode)));

end