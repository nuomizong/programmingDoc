function V=CrossMat(v)
    % converts a vector v to the matrix representing the cross-by-v

    %     if numel(v)~=3
% 	  error('CrossMat received a non-3-component argument')
%     end
%      check commented for max efficiency
% v=[v(:);0];
% V=v([4 4 2;3 4 4; 4 1 4])-v([4 3 4;4 4 1;2 4 4]);

    V=[0  -v(3) v(2);
	     v(3) 0  -v(1);
	     -v(2) v(1) 0];
    