function M=FEMBuildM(X,Tes,rho)
    % gives the FEM mass matrix M. X is an N-by-3 list of vertex coordinates,
    % Tes is an NT-by-4 matrix whose each row is made of indices of a specific
    % tetrahedron, rho is the (uniform, in this implementation) mass density.
    
tic

N=size(X,1);
NT=size(Tes,1);
% M=sparse([],[],[],3*N,3*N);
M=zeros(3*N);
D=kron(ones(4)+eye(4),eye(3) ) * 0.00833333333 * rho;   % if variant rho is needed, move the
															                 % rho factor to the M modification line.
for i=1:NT;
    ind=Tes(i,:);
    vol6 = abs(det(diff(X(ind,:))));    %6 times the tetra's volume
    ind=[3;3;3]*ind + [-2 -2 -2 -2;-1 -1 -1 -1;0 0 0 0];
    ind=ind(:);

    M(ind,ind) =M(ind,ind) + vol6*D;   % the scaling of D takes into account the 6 in vol6
end  %i

t=toc;
disp(sprintf('buildM time: %6.2g ',t));