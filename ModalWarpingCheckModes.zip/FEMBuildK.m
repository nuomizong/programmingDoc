function K=FEMBuildK(X,Tes,lambda,mu)
    % gives the FEM stiffness matrix K. X is an N-by-3 list of vertex coordinates,
    % Tes is an NT-by-4 matrix whose each row is made of indices of a specific
    % tetrahedron, lambda/mu are the lame coefficients (uniform, in this 
    % implementation) .
    % the elastic forces are K*deltaX   (without minus)

N=size(X,1);
NT=size(Tes,1);
K=zeros(3*N);
X=[X,ones(N,1)]; % for optimization in the build of beta's

for i=1:NT;
    ind=Tes(i,:)';
    beta=X(ind,:);
    vol = abs(det(beta))/6;
    beta=inv(beta');
    
    for j=1:4
	  indj=3*(ind(j)-1);
	  for k=1:4
		indk=3*(ind(k)-1);
	sigma=beta(j,1:3) * beta(k,1:3)';
		
		for a=1:3	
			for b=1:3	
				K(indj+a,indk+b)=K(indj+a,indk+b) -...
				    0.5*vol* (    lambda* beta(j,a)*beta(k,b) + mu*beta(j,b)*beta(k,a)    );
			end
		end
		K(indj+1:indj+3, indk+1:indk+3) = K(indj+1:indj+3, indk+1:indk+3) - ...
		    mu*0.5*vol*sigma*eye(3);
	  end
    end
    
end  %i
